ANATFANS Public Ready Starter — বাংলা নির্দেশিকা
================================================

এই ZIP-এ:
- index.html: ANATFANS Demo Studio; ৮টি mini-game, post, gallery, comments/likes, local chat, birthday, creator settings ও admin preview।
- assets/anat.jpg: আপনার দেওয়া ANAT-এর ছবি।
- schema.sql: Supabase/PostgreSQL database tables, RLS policies এবং private media bucket-এর starter SQL।
- README-বাংলা.txt: setup checklist।

A. Local Demo চালানো
1. ZIP Extract করুন।
2. index.html ডাবল-ক্লিক করে Chrome/Edge-এ খুলুন।
3. গেম, পোস্ট, ছবি, birthday, creator settings পরীক্ষা করুন।
4. Demo data browser localStorage-এ সেভ হয়। Browser data clear হলে মুছে যেতে পারে।

B. Database তৈরি করা
1. https://supabase.com এ অ্যাকাউন্ট খুলে New Project তৈরি করুন।
2. Project-এর SQL Editor খুলুন।
3. schema.sql-এর SQL review করে চালান।
4. Project Settings → API থেকে Project URL ও publishable/anon key নিন।
5. এগুলো ভবিষ্যৎ frontend integration-এ ব্যবহার করা যাবে। service_role/secret key কখনো browser-এ রাখবেন না।

C. Public hosting
1. Frontend Cloudflare Pages / Netlify / GitHub Pages-এ deploy করা যায়।
2. Hosting-এ deploy করলেই শুধু static demo public হবে; user accounts, database posts, real-time chat, uploads বা shared scores কাজ করবে না যতক্ষণ app.js-এ Supabase client integration যোগ ও পরীক্ষা করা না হয়।
3. Supabase Auth Site URL এবং Redirect URLs deployed domain অনুযায়ী সেট করুন।
4. Username/password-only signup চাইলে নিরাপদ server-side username-to-account flow দরকার। Fake email pattern দিয়ে সরাসরি production authentication করা নিরাপদ নয়; rate limiting ও username collision handling লাগবে।

D. Public launch-এর আগে আবশ্যক
- Supabase Auth integration (signup/login/logout/reset/username uniqueness)
- Frontend CRUD wired to Supabase tables
- Real image upload and private storage access
- Realtime chat
- Notifications triggers/functions
- Server-verified score submissions; client score alone সহজে বদলানো যায়
- Admin role trusted server থেকে; browser থেকে কখনো admin self-assign নয়
- Report/block/moderation, spam/rate limiting, backups, privacy policy, terms, mobile testing
- দুইটি normal account ও একটি admin account দিয়ে RLS test

গুরুত্বপূর্ণ নিরাপত্তা:
- schema.sql একটি starter; SQL policy run হওয়ার আগে Supabase project-এর অবস্থা যাচাই করুন।
- SQL migration-এ object/policy আগে থেকে থাকলে duplicate policy error হতে পারে; নতুন project-এ চালানো সহজ।
- শিশুর ছবি public করার আগে অভিভাবকের সম্মতি এবং privacy নিশ্চিত করুন।
- এই ZIP নিজে থেকে public live website নয়। Database setup ও frontend integration এখনও করতে হবে। Loading page, homepage ও footer-এ “JESAN RAHMAN” creator credit যোগ করা হয়েছে। Public URL পেতে hosting account-এ deploy করতে হবে।


নতুন গেম আপডেট:
- Rock Paper Scissors
- Tic-Tac-Toe vs Bot
- Reaction Test
- আগের Leaf Catcher, Nature Quiz, Memory Match, Catch the Butterfly, Number Puzzle

Language style: Bangla + English mixed (Banglish), যাতে local members সহজে বুঝতে পারে।
