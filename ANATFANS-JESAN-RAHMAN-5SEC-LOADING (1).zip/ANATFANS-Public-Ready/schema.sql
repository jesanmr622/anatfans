-- ANATFANS Public Database Starter (Supabase / PostgreSQL)
-- Review and run in Supabase SQL Editor only after creating a project.
-- This schema is a secure baseline, not a substitute for testing policies.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 24),
  display_name text not null default 'ANATFANS Member',
  avatar_url text,
  bio text not null default '',
  birthday date,
  social_links jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null default '' check (char_length(body) <= 5000),
  image_path text,
  visibility text not null default 'public' check (visibility in ('public','members')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint posts_nonempty check (char_length(trim(body)) > 0 or image_path is not null)
);

create table if not exists public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(post_id,user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  room text not null default 'lobby' check (char_length(room) between 1 and 40),
  body text not null check (char_length(trim(body)) between 1 and 1500),
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  kind text not null check (kind in ('like','comment','mention','system')),
  post_id uuid references public.posts(id) on delete cascade,
  body text not null default '' check (char_length(body) <= 500),
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.birthday_entries (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  label text not null check (char_length(trim(label)) between 1 and 80),
  birthday date not null,
  created_at timestamptz not null default now()
);

create table if not exists public.game_scores (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  game_key text not null check (game_key in ('leaf_catcher','nature_quiz','memory_match','butterfly_catch','number_puzzle')),
  score integer not null check (score between 0 and 100000),
  duration_ms integer check (duration_ms is null or duration_ms between 0 and 3600000),
  created_at timestamptz not null default now()
);

create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists comments_post_created_idx on public.comments(post_id, created_at);
create index if not exists chat_room_created_idx on public.chat_messages(room, created_at desc);
create index if not exists notifications_recipient_created_idx on public.notifications(recipient_id, created_at desc);
create index if not exists scores_game_score_idx on public.game_scores(game_key, score desc);

-- Admins must be granted by a trusted server/admin process; never let a client self-assign admin.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin', false);
$$;

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.post_likes enable row level security;
alter table public.comments enable row level security;
alter table public.chat_messages enable row level security;
alter table public.notifications enable row level security;
alter table public.birthday_entries enable row level security;
alter table public.game_scores enable row level security;

create policy "Profiles are viewable by members" on public.profiles for select to authenticated using (true);
create policy "Users create their own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id or public.is_admin()) with check (auth.uid() = id or public.is_admin());
create policy "Admins can delete profiles" on public.profiles for delete to authenticated using (public.is_admin());

create policy "Posts viewable by signed-in members" on public.posts for select to authenticated using (visibility = 'public' or user_id = auth.uid() or public.is_admin());
create policy "Members create own posts" on public.posts for insert to authenticated with check (user_id = auth.uid());
create policy "Owners update posts" on public.posts for update to authenticated using (user_id = auth.uid() or public.is_admin()) with check (user_id = auth.uid() or public.is_admin());
create policy "Owners or admins delete posts" on public.posts for delete to authenticated using (user_id = auth.uid() or public.is_admin());

create policy "Likes visible to members" on public.post_likes for select to authenticated using (true);
create policy "Users like as themselves" on public.post_likes for insert to authenticated with check (user_id = auth.uid());
create policy "Users unlike own likes" on public.post_likes for delete to authenticated using (user_id = auth.uid() or public.is_admin());

create policy "Comments visible to members" on public.comments for select to authenticated using (true);
create policy "Users comment as themselves" on public.comments for insert to authenticated with check (user_id = auth.uid());
create policy "Users or admins delete comments" on public.comments for delete to authenticated using (user_id = auth.uid() or public.is_admin());

create policy "Chat visible to members" on public.chat_messages for select to authenticated using (true);
create policy "Users send own chat" on public.chat_messages for insert to authenticated with check (user_id = auth.uid());
create policy "Users or admins delete chat" on public.chat_messages for delete to authenticated using (user_id = auth.uid() or public.is_admin());

create policy "Users see own notifications" on public.notifications for select to authenticated using (recipient_id = auth.uid() or public.is_admin());
create policy "Users mark own notifications read" on public.notifications for update to authenticated using (recipient_id = auth.uid()) with check (recipient_id = auth.uid());
create policy "Admins manage notifications" on public.notifications for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "Users manage own birthday entries" on public.birthday_entries for all to authenticated using (owner_id = auth.uid() or public.is_admin()) with check (owner_id = auth.uid() or public.is_admin());

create policy "Members view game scores" on public.game_scores for select to authenticated using (true);
create policy "Users submit own scores" on public.game_scores for insert to authenticated with check (user_id = auth.uid());
create policy "Admins delete scores" on public.game_scores for delete to authenticated using (public.is_admin());

-- Storage bucket for profile photos and post images.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('anatfans-media', 'anatfans-media', false, 5242880, array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do nothing;

create policy "Signed-in members read media" on storage.objects for select to authenticated
using (bucket_id = 'anatfans-media');
create policy "Members upload own media path" on storage.objects for insert to authenticated
with check (bucket_id = 'anatfans-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Members update own media path" on storage.objects for update to authenticated
using (bucket_id = 'anatfans-media' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'anatfans-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Members delete own media path" on storage.objects for delete to authenticated
using (bucket_id = 'anatfans-media' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- Optional: enable Realtime in Supabase Dashboard for chat_messages and notifications.
-- Important launch tasks not covered by SQL alone:
-- 1) configure Auth signup flow and username availability checks with rate limiting,
-- 2) configure Realtime publication,
-- 3) server-side notification triggers/functions,
-- 4) admin role assignment via trusted server only,
-- 5) moderation/report/block tools, retention and backups,
-- 6) verify every RLS policy with two normal users and one admin before public launch.
